package dk.tec.maso41;

public enum MatchEnum {
	MatchPersonId, MatchPerson, 
	MatchHaircolor, MatchHaircolorId,
	MatchProgrammingLanguage, MatchProgrammingLanguageId,
	MatchNo;
}
