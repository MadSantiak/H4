/**
 * 
 */
/**
 * 
 */
module SimpleGreenRedBox {
	requires java.desktop;
}